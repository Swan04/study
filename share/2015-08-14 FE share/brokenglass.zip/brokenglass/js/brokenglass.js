/*
 * 破碎玻璃效果
 */
define('brokenglass', function() {
	var BrokenGlass = function(option) {
		if (!option.broken_image) {
			throw('请输入要碎裂的图片');
		}
		
		var pieces = [],
		broken_image = option.broken_image,
		render = new CanvasRender({
			canvas : option.canvas,
			// 不做2倍缩放
			global_scale : 1,
			// debug : true
		}),
		longi = option.longitude > 4 && parseInt(option.longitude) || 12,
		lati = option.latitude > 3 && parseInt(option.latitude) || 5,
		scale_step = option.scale_step <= 0.8 && option.scale_step >= 0.1 && parseFloat(option.scale_step) || 0.5,
		turn_speed = option.turn_speed < 0.1 && option.turn_speed > 0 && parseFloat(option.turn_speed) || 0.05;
		
		Class.imageCache[broken_image.src] = broken_image;
		
		this.width = option.width || document.documentElement.clientWidth;
		this.height = option.height || document.documentElement.clientHeight;
		
		Object.defineProperties(this, {
			render : {
				get : function() {
					return render;
				}
			},
			pieces : {
				get : function() {
					return pieces;
				}
			},
			longitude : {
				get : function() {
					return longi;
				}
			},
			latitude : {
				get : function() {
					return lati;
				}
			},
			scale_step : {
				get : function() {
					return scale_step;
				}
			},
			turn_speed : {
				get : function() {
					return turn_speed;
				}
			},
			broken_image : {
				get : function() {
					return broken_image;
				}
			}
		});
		
		this.render.appendChild(new Class.display.Sprite({
			extraRender : function() {
				this.stage.ctx.drawImage(broken_image, 0, 0);
			}
		}));
	};
	BrokenGlass.prototype = {
		constructor : BrokenGlass,
		/*
		 * 创建破碎玻璃块
		 */
		createBroken : function() {
			// 首先清除原始图
			this.render.children[0].remove();
			
			var self = this,
			r_max = Math.max(this.width, this.height), // 简单粗暴……最大半径等于最小边长
			lines = [], // 记录所有的线条
			center_x = this.width / 2, center_y = this.height / 2, center = new Class.geom.Point(center_x, center_y);
			
			for (var gi = 0, gl = this.longitude; gi < gl; gi++) {
				var _corner = gi * 360 / gl + Math.random() * 180 / gl - 90 / gl, // 本条直线的角度
				points = []; // 记录本条直线的节点
				for (var ti = 1, tl = this.latitude; ti < tl; ti++) {
					// 缩放比例
					var scale = Math.pow(this.scale_step, tl - ti);
					
					// 计算随机偏移半径
					var r = r_max * scale, r_real = r * (1.2 - Math.random() * 0.4);
					// 计算随机偏移角度
					var c_real = _corner + Math.random() * 90 / gl - 45 / gl;
					// 生成最终随机偏移节点
					var _x = r_real * Math.cos(c_real * Math.PI / 180), _y = r_real * Math.sin(c_real * Math.PI / 180);
					
					points.push(new Class.geom.Point(_x + center_x, _y + center_y));
				}
				points.push(new Class.geom.Point(r_max * Math.cos(_corner * Math.PI / 180) + center_x, r_max * Math.sin(_corner * Math.PI / 180) + center_y));
				lines.push({
					corner : _corner,
					points : points
				});
				
				if (gi > 0) {
					
				}
			}
			
			var extraRender = function() {
				this.stage.ctx.save();
				this.stage.ctx.scale(this.scale * this.scaleX, this.scale * this.scaleY);
				
				this.stage.ctx.beginPath();
				this.stage.ctx.moveTo(this.point1.x - this.x, this.point1.y - this.y);
				this.stage.ctx.lineTo(this.point2.x - this.x, this.point2.y - this.y);
				this.stage.ctx.lineTo(this.point3.x - this.x, this.point3.y - this.y);
				this.stage.ctx.lineTo(this.point1.x - this.x, this.point1.y - this.y);
				this.stage.ctx.clip();
				// this.stage.ctx.drawImage(self.broken_image, -center_x - _center_x, -center_y - _center_y);
				this.stage.ctx.drawImage(self.broken_image, -this.x, -this.y);
				
				this.stage.ctx.restore();
			},
			oninit = function() {
				var min_x = Math.max(0, Math.min(this.point1.x, this.point2.x, this.point3.x)),
				min_y = Math.max(0, Math.min(this.point1.y, this.point2.y, this.point3.y)),
				max_x = Math.min(self.width, Math.max(this.point1.x, this.point2.x, this.point3.x)),
				max_y = Math.min(self.height, Math.max(this.point1.y, this.point2.y, this.point3.y));
				this.x = (min_x + max_x) / 2;
				this.y = (min_y + max_y) / 2;
				this.basex = this.x;
				this.basey = this.y;
			},
			animeProp = {
				progress : function(ev) {
					var scale = 1 - ev.ease * ev.ease;
					
					var scaleX = this.piece.scaleX - this.piece.scaleXSpeed * ev.ease;
					if (scaleX <= -1) {
						if (this.piece.scaleXSpeed > 0) {
							this.piece.scaleXSpeed *= -1;
						}
					} else if (scaleX >= 1) {
						if (this.piece.scaleXSpeed < 0) {
							this.piece.scaleXSpeed *= -1;
						}
					}
					
					var scaleY = this.piece.scaleY - this.piece.scaleYSpeed * ev.ease;
					if (scaleY <= -1) {
						if (this.piece.scaleYSpeed > 0) {
							this.piece.scaleYSpeed *= -1;
						}
					} else if (this.scaleY >= 1) {
						if (this.piece.scaleYSpeed < 0) {
							this.piece.scaleYSpeed *= -1;
						}
					}
			
					var _x = center_x - (center_x - this.piece.basex) * scale, _y = center_y - (center_y - this.piece.basey) * scale - center_y * 0.5 * Math.abs(0.5 - Math.pow(ev.percent, 0.1));
			
					this.piece.setProp({
						scale : scale,
						x : _x,
						y : _y,
						scaleX : scaleX,
						scaleY : scaleY,
						alpha : scaleX * scaleY
					});
				},
				after : function() {
					this.piece.remove();
				},
				easing : 'circin'
			};
			
			for (var i = 0, l = lines.length; i < l; i++) {
				var line_this = lines[i], line_next = (i === l - 1) ? lines[0] : lines[i+1];
				for (var pi = 0, pl = line_this.points.length; pi < pl; pi++) {
					if (pi === 0) {
						// 从原点开始的，创建一个三角形碎片
						var piece = new Class.display.Sprite({
							extraRender : extraRender
						});
						piece.point1 = center;
						piece.point2 = line_this.points[0];
						piece.point3 = line_next.points[0];
						piece.scale = 1;
						piece.scaleX = 1;
						piece.scaleY = 1;
						piece.scaleXSpeed = Math.random() * this.turn_speed;
						piece.scaleYSpeed = Math.random() * this.turn_speed;
						oninit.apply(piece);
						this.render.appendChildAt(piece, 0);
						
						var duration = 4000 + Math.random() * 200;
						if (Math.random() > 0.9) {
							duration -= 1000;
						}
						animeProp.duration = duration;
						animeProp.delay = 0;
						var anime = SimpleAnime(animeProp);
						anime.piece = piece;
						
					} else {
						// 不是从原点开始，则分隔为两个三角形碎片
						var piece1 = new Class.display.Sprite({
							extraRender : extraRender
						}),
						piece2 = new Class.display.Sprite({
							extraRender : extraRender
						});
						this.render.appendChildAt(piece1, pi * 2 - 1 + i * l);
						this.render.appendChildAt(piece2, pi * 2 + i * l);
						
						piece1.point1 = line_this.points[pi - 1];
						piece1.point2 = line_next.points[pi - 1];
						piece2.point1 = line_this.points[pi];
						piece2.point2 = line_next.points[pi];
						
						piece1.scale = 1;
						piece1.scaleX = 1;
						piece1.scaleY = 1;
						piece1.scaleXSpeed = Math.random() * this.turn_speed;
						piece1.scaleYSpeed = Math.random() * this.turn_speed;
						
						piece2.scale = 1;
						piece2.scaleX = 1;
						piece2.scaleY = 1;
						piece2.scaleXSpeed = Math.random() * this.turn_speed;
						piece2.scaleYSpeed = Math.random() * this.turn_speed;
						
						if (i % 2 === 0) {
							piece1.point3 = line_this.points[pi];
							piece2.point3 = line_next.points[pi - 1];
						} else {
							piece1.point3 = line_next.points[pi];
							piece2.point3 = line_this.points[pi - 1];
						}
						
						oninit.apply(piece1);
						oninit.apply(piece2);
						
						var duration1 = 4000 + Math.random() * 200 * (pi + 1);
						if (Math.random() > 0.9) {
							duration1 -= 1000;
						}
						animeProp.duration = duration1;
						animeProp.delay = 400 * Math.pow(pi, 0.5);
						var anime1 = SimpleAnime(animeProp);
						anime1.piece = piece1;
						
						var duration2 = 4000 + Math.random() * 200 * (pi + 1);
						if (Math.random() > 0.9) {
							duration2 -= 1000;
						}
						animeProp.duration = duration2;
						animeProp.delay = 400 * Math.pow(pi, 0.5);
						var anime2 = SimpleAnime(animeProp);
						anime2.piece = piece2;
					}
				}
				
			}
		}
	};
	
	window.BrokenGlass = BrokenGlass;
	return BrokenGlass;
});
