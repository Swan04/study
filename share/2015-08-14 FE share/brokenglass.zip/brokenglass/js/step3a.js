/*
 * 破碎玻璃效果
 */
(function() {
	var BrokenGlass = function(option) {
		if (!option.broken_image) {
			throw('请输入要碎裂的图片');
		}
		
		var pieces = [],
		broken_image = option.broken_image,
		render = new CanvasRender({
			canvas : option.canvas,
			// 不做2倍缩放
			global_scale : 1,
			// debug : true
		}),
		longi = option.longitude > 4 && parseInt(option.longitude) || 12,
		lati = option.latitude > 3 && parseInt(option.latitude) || 5,
		scale_step = option.scale_step <= 0.8 && option.scale_step >= 0.1 && parseFloat(option.scale_step) || 0.5,
		turn_speed = option.turn_speed < 0.1 && option.turn_speed > 0 && parseFloat(option.turn_speed) || 0.05,
		usetime = option.usetime > 1000 && parseInt(option.usetime) || 2000;
		
		Class.imageCache[broken_image.src] = broken_image;
		
		this.width = option.width || document.documentElement.clientWidth;
		this.height = option.height || document.documentElement.clientHeight;
		
		Object.defineProperties(this, {
			render : {
				get : function() {
					return render;
				}
			},
			pieces : {
				get : function() {
					return pieces;
				}
			},
			longitude : {
				get : function() {
					return longi;
				}
			},
			latitude : {
				get : function() {
					return lati;
				}
			},
			scale_step : {
				get : function() {
					return scale_step;
				}
			},
			turn_speed : {
				get : function() {
					return turn_speed;
				}
			},
			usetime : {
				get : function() {
					return usetime;
				}
			},
			broken_image : {
				get : function() {
					return broken_image;
				}
			}
		});
		
		this.render.appendChild(new Class.display.Sprite({
			extraRender : function() {
				this.stage.ctx.drawImage(broken_image, 0, 0);
			}
		}));
	};
	BrokenGlass.prototype = {
		constructor : BrokenGlass,
		/*
		 * 创建破碎玻璃块
		 */
		createBroken : function() {
			// 首先清除原始图
			this.render.children[0].remove();
			
			var self = this,
			r_max = Math.max(this.width, this.height), // 简单粗暴……最大半径等于最小边长
			lines = [], // 记录所有的线条
			center = new Class.geom.Point(self.width / 2, self.height / 2);
			
			for (var gi = 0, gl = this.longitude; gi < gl; gi++) {
				var _corner = gi * 360 / gl + Math.random() * 180 / gl - 90 / gl; // 本条直线的角度
				for (var ti = 1, tl = this.latitude; ti < tl; ti++) {
					if (!lines[ti - 1]) {
						lines[ti - 1] = [];
					}
					// 缩放比例
					var scale = Math.pow(this.scale_step, tl - ti);
					
					// 计算随机偏移半径
					var r = r_max * scale, r_real = r * (1.2 - Math.random() * 0.4);
					// 计算随机偏移角度
					var c_real = _corner + Math.random() * 90 / gl - 45 / gl;
					// 生成最终随机偏移节点
					var _x = r_real * Math.cos(c_real * Math.PI / 180), _y = r_real * Math.sin(c_real * Math.PI / 180);
					
					lines[ti - 1].push(new Class.geom.Point(_x + self.width / 2, _y + self.height / 2));
				}
				
				if (!lines[tl - 1]) {
					lines[tl - 1] = [];
				}
				lines[tl - 1].push(new Class.geom.Point(r_max * Math.cos(_corner * Math.PI / 180) + self.width / 2, r_max * Math.sin(_corner * Math.PI / 180) + self.height / 2));
			}
			
			var extraRender = function() {
				this.stage.ctx.save();
				this.stage.ctx.scale(this.scale * this.scaleX, this.scale * this.scaleY);
				
				this.stage.ctx.beginPath();
				this.stage.ctx.lineWidth = 3;
				this.stage.ctx.moveTo(this.point1.x - this.x, this.point1.y - this.y);
				this.stage.ctx.lineTo(this.point2.x - this.x, this.point2.y - this.y);
				this.stage.ctx.lineTo(this.point3.x - this.x, this.point3.y - this.y);
				this.stage.ctx.lineTo(this.point1.x - this.x, this.point1.y - this.y);
				this.stage.ctx.stroke();
				this.stage.ctx.clip();
				this.stage.ctx.drawImage(self.broken_image, -this.x, -this.y);
				
				this.stage.ctx.restore();
			},
			oninit = function() {
				var min_x = Math.max(0, Math.min(this.point1.x, this.point2.x, this.point3.x)),
				min_y = Math.max(0, Math.min(this.point1.y, this.point2.y, this.point3.y)),
				max_x = Math.min(self.width, Math.max(this.point1.x, this.point2.x, this.point3.x)),
				max_y = Math.min(self.height, Math.max(this.point1.y, this.point2.y, this.point3.y));
				this.x = (min_x + max_x) / 2;
				this.y = (min_y + max_y) / 2;
				this.basex = this.x;
				this.basey = this.y;
			},
			animeProp = {
				progress : function(ev) {
					var scale = 1 - ev.ease * ev.ease;
					/*
					var scaleX = this.piece.scaleX - this.piece.scaleXSpeed * ev.ease;
					if (scaleX <= -1) {
						if (this.piece.scaleXSpeed > 0) {
							this.piece.scaleXSpeed *= -1;
						}
					} else if (scaleX >= 1) {
						if (this.piece.scaleXSpeed < 0) {
							this.piece.scaleXSpeed *= -1;
						}
					}
					
					var scaleY = this.piece.scaleY - this.piece.scaleYSpeed * ev.ease;
					if (scaleY <= -1) {
						if (this.piece.scaleYSpeed > 0) {
							this.piece.scaleYSpeed *= -1;
						}
					} else if (this.scaleY >= 1) {
						if (this.piece.scaleYSpeed < 0) {
							this.piece.scaleYSpeed *= -1;
						}
					}
					var _x = self.width / 2 - (self.width / 2 - this.piece.basex) * scale, _y = self.height / 2 - (self.height / 2 - this.piece.basey) * scale - self.height / 2 * 0.5 * Math.abs(0.5 - Math.pow(ev.percent, 0.1));
					
					this.piece.setProp({
						scale : scale,
						x : _x,
						y : _y
					});
					*/
				},
				after : function() {
					// this.piece.remove();
				},
				easing : 'circin'
			};
			
			for (var i = 0, l = lines.length; i < l; i++) {
				var line_this = lines[i], pi = 0, pl = line_this.length;
				if (i === 0) {
					// 从原点开始的，创建一个三角形碎片
					for (; pi < pl; pi++) {
						var piece = new Class.display.Sprite({
							extraRender : extraRender
						}),
						point_this = line_this[pi], // 当前点
						point_next = (pi === pl - 1) ? line_this[0] : line_this[pi + 1]; // 三角形的另一顶点
						
						piece.point1 = center; // 基础顶点为原点
						piece.point2 = point_this;
						piece.point3 = point_next;
						piece.scale = 1;
						piece.scaleX = 1;
						piece.scaleY = 1;
						piece.scaleXSpeed = Math.random() * this.turn_speed;
						piece.scaleYSpeed = Math.random() * this.turn_speed;
						oninit.apply(piece);
						this.render.appendChildAt(piece, 0);
						
						var duration = this.usetime + Math.random() * this.usetime / 10;
						animeProp.duration = duration;
						animeProp.delay = 0;
						var anime = SimpleAnime(animeProp);
						anime.piece = piece;
					}
				} else {
					for (; pi < pl; pi++) {
						// 不是从原点开始，则分隔为两个三角形碎片
						var piece1 = new Class.display.Sprite({
							extraRender : extraRender
						}),
						piece2 = new Class.display.Sprite({
							extraRender : extraRender
						}),
						line_prev = lines[i - 1], // 前一条纬度线
						point0 = line_this[pi], // 当前点
						point1, // 三角形另一顶点
						point0_prev = line_prev[pi], // 当前点在前一条纬度线的对应点
						point1_prev; // 三角形另一顶点在前一条纬度线的对应点
						
						if (pi === pl - 1) {
							point1 = line_this[0];
							point1_prev = line_prev[0];
						} else {
							point1 = line_this[pi + 1];
							point1_prev = line_prev[pi + 1];
						}
						
						this.render.appendChild(piece1);
						this.render.appendChild(piece2);
						
						piece1.point1 = point0;
						piece1.point2 = point1;
						piece2.point1 = point0_prev;
						piece2.point2 = point1_prev;
						
						if ((pi + i) % 2 === 0) {
							piece1.point3 = point0_prev;
							piece2.point3 = point1;
						} else {
							piece1.point3 = point1_prev;
							piece2.point3 = point0;
						}
						
						piece1.scale = 1;
						piece1.scaleX = 1;
						piece1.scaleY = 1;
						piece1.scaleXSpeed = Math.random() * this.turn_speed;
						piece1.scaleYSpeed = Math.random() * this.turn_speed;
						
						piece2.scale = 1;
						piece2.scaleX = 1;
						piece2.scaleY = 1;
						piece2.scaleXSpeed = Math.random() * this.turn_speed;
						piece2.scaleYSpeed = Math.random() * this.turn_speed;
						
						oninit.apply(piece1);
						oninit.apply(piece2);
						
						var duration1 = this.usetime + Math.random() * this.usetime / 10 * i;
						animeProp.duration = duration1;
						animeProp.delay = this.usetime / 5 * Math.pow(i, 0.5);
						var anime1 = SimpleAnime(animeProp);
						anime1.piece = piece1;
						
						var duration2 = this.usetime + Math.random() * this.usetime / 10 * i;
						animeProp.duration = duration2;
						animeProp.delay = this.usetime / 5 * Math.pow(i, 0.5);
						var anime2 = SimpleAnime(animeProp);
						anime2.piece = piece2;
					}
				}
			}
		}
	};
	
	window.BrokenGlass = BrokenGlass;
})();

/*
 * 跨屏彩蛋控制器
 */
(function() {
	var winWidth = document.documentElement.clientWidth, winHeight = document.documentElement.clientHeight,
	// 搜索结果DOM
	header = document.getElementById('header'), wrapper = document.getElementById('warper'),
	// canvas对象
	canvas = document.createElement('canvas'),
	// context画布
	context,
	// 用于切割的图片
	broken_image,
	broken_glass,
	last_frame,
	lastFrame,
	// 片尾循环创建光束的动画
	piece_creater,
	// 屏幕呼吸动画
	screen_breath,
	isExit = false,
	start_time,
	// 初始化
	init = function(topImage) {
		html2canvas(document.body, {
			background : '#fff',
			proxy : true,
			useCORS : true,
			onrendered : function(c) {
				header && (header.style.display = 'none');
				wrapper && (wrapper.style.display = 'none');
					
				var easterEgg = document.createElement('div');
				easterEgg.id = 'easterEgg';
				document.body.appendChild(easterEgg);
				
				easterEgg.innerHTML = [
					'<style>',
					'#easterEgg{height:100%;left:0;position:fixed;top:0;width:100%;z-index:9999;}',
					'</style>',
				].join('');
				
				var c_ctx = c.getContext('2d');
				c_ctx.drawImage(topImage, 0, 0, 80, 42, 20, 8, 80, 42);
				c_ctx.drawImage(topImage, 540, 42, 93, 36, 560, 50, 93, 36);
				
				easterEgg.addEventListener('click', function(ev) {
					if (ev.target.id === 'easter_egg_close') {
						exit();
					} else if (ev.target.id === 'easter_egg_quiet') {
						if (ev.target.className === 'quiet') {
							ev.target.className = '';
						} else {
							ev.target.className = 'quiet';
						}
					}
				});
				
				winWidth = document.documentElement.clientWidth, winHeight = document.documentElement.clientHeight;
				canvas.width = winWidth;
				canvas.height = winHeight;
				easterEgg.appendChild(canvas);
		
				start_time = SimpleAnime.getTime();
				broken_image = c;
				throwPhone();
		
				window.addEventListener('resize', function() {
					winWidth = document.documentElement.clientWidth, winHeight = document.documentElement.clientHeight;
					broken_glass.width = winWidth;
					broken_glass.height = winHeight;
				});
			}
		});
	},
	// 图片预加载
	preload = function() {
		// 判断是否支持canvas
		try {
			context = canvas.getContext('2d');
		} catch(e) {
			return;
		}
		
		var topImage = new Image;
		topImage.onload = function() {
			init(topImage);
		};
		topImage.src = 'https://p.ssl.qhimg.com/t01bd2904efdacbc51a.png';
	},
	throwPhone = function() {
		broken_glass = new BrokenGlass({
			canvas : canvas,
			width : winWidth,
			height : winHeight,
			broken_image : broken_image,
			longitude : 21,
			latitude : 7,
			scale_step : 0.6,
			usetime : 2000
		});
		document.getElementById('easterEgg').style['background-color'] = '#000';
		
		broken_glass.createBroken();
	},
	createPiece = function() {
		piece_creater = SimpleAnime({
			duration : 50,
			loop : 0,
			beforeloop : function() {
				var piece = new Class.display.Sprite({
					x : winWidth / 2,
					y : winHeight / 2,
					extraRender : function() {
						this.stage.ctx.save();
						this.stage.ctx.scale(this.scale, this.scale);
						this.stage.ctx.fillStyle = '#c6ff8f';
						this.stage.ctx.beginPath();
						this.stage.ctx.moveTo(this.point0.x, this.point0.y);
						this.stage.ctx.lineTo(this.point1.x, this.point1.y);
						this.stage.ctx.lineTo(this.point2.x, this.point2.y);
						this.stage.ctx.lineTo(this.point0.x, this.point0.y);
						this.stage.ctx.fill();
						this.stage.ctx.restore();
					}
				});
				var corner = Math.random() * 360, angel = Math.random() + 1, side1 = Math.random() * 20 + 10, side2 = Math.random() * 20 + 10;
				piece.scale = 1;
				piece.point0 = new Class.geom.Point(0, 0);
				piece.point1 = new Class.geom.Point(side1 * Math.cos((corner - angel) * Math.PI / 180), side1 * Math.sin((corner - angel) * Math.PI / 180));
				piece.point2 = new Class.geom.Point(side2 * Math.cos((corner + angel) * Math.PI / 180), side2 * Math.sin((corner + angel) * Math.PI / 180));
				
				broken_glass.render.appendChildAt(piece, 0);
				
				SimpleAnime({
					duration : Math.random() * 1200 + 300,
					progress : function(ev) {
						piece.setProp({
							x : winWidth / 2 * (1 + ev.ease * Math.cos(corner * Math.PI / 180)),
							y : winHeight / 2 + winWidth / 2 * ev.ease * Math.sin(corner * Math.PI / 180),
							scale : 1 + ev.ease * 9,
							alpha : 1 - ev.ease
						});
					},
					after : function() {
						piece.remove();
					}
				});
			}
		});
	};
	
	preload();
})();