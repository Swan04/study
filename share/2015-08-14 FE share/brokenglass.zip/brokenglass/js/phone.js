/*
 * 跨屏彩蛋控制器
 */
(function() {
	var winWidth = document.documentElement.clientWidth, winHeight = document.documentElement.clientHeight,
	// 搜索结果DOM
	header = document.getElementById('header'), wrapper = document.getElementById('warper'),
	// canvas对象
	canvas = document.createElement('canvas'),
	// context画布
	context,
	broken_glass,
	last_frame,
	lastFrame,
	phone,
	// 手机翻转动画
	phone_frame,
	phoneFrames = [],
	// 片尾循环创建光束的动画
	piece_creater,
	// 屏幕呼吸动画
	screen_breath,
	isExit = false,
	start_time,
	// 初始化
	// 图片预加载
	preload = function() {
		// 判断是否支持canvas
		try {
			context = canvas.getContext('2d');
		} catch(e) {
			return;
		}
		
		var imgs = [
			'https://p.ssl.qhimg.com/t01626bf08dc16c3b94.png', 'https://p.ssl.qhimg.com/t0192b858d2733c1438.png', 'https://p.ssl.qhimg.com/t012b7e2633f0815c13.png', 'https://p.ssl.qhimg.com/t01b0ea3119b1cc4e42.png', 'https://p.ssl.qhimg.com/t018752feea96251302.png', 'https://p.ssl.qhimg.com/t01dab69f8a34669dcb.png',
			'https://p.ssl.qhimg.com/t01710b6162aca41b4a.png', 'https://p.ssl.qhimg.com/t0183d95fed5b107baf.png', 'https://p.ssl.qhimg.com/t01f66c85ed30546ac9.png', 'https://p.ssl.qhimg.com/t01c22dad3a9cc6179f.png', 'https://p.ssl.qhimg.com/t012f31282d11b57be9.png', 'https://p.ssl.qhimg.com/t01ce3d94ce5b6d291b.png'],
		l = imgs.length, loaded = 0, topImage;
		for (var i = 0; i < l; i++) {
			var img = new Image;
			phoneFrames.push(img);
			img.onload = function() {
				if (++loaded === l) {
					throwPhone();
				}
			};
			img.src = imgs[i];
			
		}
	},
	throwPhone = function() {
		document.body.appendChild(canvas);
		broken_glass = new CanvasRender({
			canvas : canvas,
			global_scale : 1
		});
		
		phone = new Class.display.Sprite({
			x : winWidth / 2,
			y : winHeight / 2,
			extraRender : function() {
				this.stage.ctx.save();
				this.stage.ctx.scale(this.scale, this.scale);
				this.stage.ctx.drawImage(phoneFrames[this.frame], -300, -360 + this.extraY);
				this.stage.ctx.restore();
			}
		});
		phone.addEventListener('resize', function() {
			SimpleAnime.raf(function() {
				this.x = winWidth / 2;
				this.y = winHeight / 2;
			}, this);
		});
		phone.frame = 0;
		phone.extraY = 0;
		
		broken_glass.appendChild(phone);
		
		var punched = false;
		phone_frame = SimpleAnime({
			loop : 0,
			duration : 100,
			beforeloop : function(ev) {
				var frame = phone.frame + 1;
				if (frame === 12) {
					frame = 0;
				}
				phone.setProp({
					frame : frame
				});
			}
		});
		
		document.body.addEventListener('click', function() {
			if (!punched) {
				punched = true;
				SimpleAnime({
					delay : 200,
					duration : 2000,
					progress : function(ev) {
						phone.setProp({
							scale : 4 - ev.ease * 3,
							extraY : winHeight / 2 * (1 - SimpleAnime.getEasing(ev.percent, 'circ')[0]),
							alpha : ev.ease
						});
					},
					after : function() {
						punched = false;
					}
				});
			}
		});
	};
	
	preload();
})();