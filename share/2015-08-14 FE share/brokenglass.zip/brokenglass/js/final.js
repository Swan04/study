/*
 * 破碎玻璃效果
 */
(function() {
	var BrokenGlass = function(option) {
		if (!option.broken_image) {
			throw('请输入要碎裂的图片');
		}
		
		var pieces = [],
		broken_image = option.broken_image,
		render = new CanvasRender({
			canvas : option.canvas,
			// 不做2倍缩放
			global_scale : 1,
			// debug : true
		}),
		longi = option.longitude > 4 && parseInt(option.longitude) || 12,
		lati = option.latitude > 3 && parseInt(option.latitude) || 5,
		scale_step = option.scale_step <= 0.8 && option.scale_step >= 0.1 && parseFloat(option.scale_step) || 0.5,
		turn_speed = option.turn_speed < 0.1 && option.turn_speed > 0 && parseFloat(option.turn_speed) || 0.05,
		usetime = option.usetime > 1000 && parseInt(option.usetime) || 2000;
		
		Class.imageCache[broken_image.src] = broken_image;
		
		this.width = option.width || document.documentElement.clientWidth;
		this.height = option.height || document.documentElement.clientHeight;
		
		Object.defineProperties(this, {
			render : {
				get : function() {
					return render;
				}
			},
			pieces : {
				get : function() {
					return pieces;
				}
			},
			longitude : {
				get : function() {
					return longi;
				}
			},
			latitude : {
				get : function() {
					return lati;
				}
			},
			scale_step : {
				get : function() {
					return scale_step;
				}
			},
			turn_speed : {
				get : function() {
					return turn_speed;
				}
			},
			usetime : {
				get : function() {
					return usetime;
				}
			},
			broken_image : {
				get : function() {
					return broken_image;
				}
			}
		});
		
		this.render.appendChild(new Class.display.Sprite({
			extraRender : function() {
				this.stage.ctx.drawImage(broken_image, 0, 0);
			}
		}));
	};
	BrokenGlass.prototype = {
		constructor : BrokenGlass,
		/*
		 * 创建破碎玻璃块
		 */
		createBroken : function() {
			// 首先清除原始图
			this.render.children[0].remove();
			
			var self = this,
			r_max = Math.max(this.width, this.height), // 简单粗暴……最大半径等于最小边长
			lines = [], // 记录所有的线条
			center = new Class.geom.Point(self.width / 2, self.height / 2);
			
			for (var gi = 0, gl = this.longitude; gi < gl; gi++) {
				var _corner = gi * 360 / gl + Math.random() * 180 / gl - 90 / gl; // 本条直线的角度
				for (var ti = 1, tl = this.latitude; ti < tl; ti++) {
					if (!lines[ti - 1]) {
						lines[ti - 1] = [];
					}
					// 缩放比例
					var scale = Math.pow(this.scale_step, tl - ti);
					
					// 计算随机偏移半径
					var r = r_max * scale, r_real = r * (1.2 - Math.random() * 0.4);
					// 计算随机偏移角度
					var c_real = _corner + Math.random() * 90 / gl - 45 / gl;
					// 生成最终随机偏移节点
					var _x = r_real * Math.cos(c_real * Math.PI / 180), _y = r_real * Math.sin(c_real * Math.PI / 180);
					
					lines[ti - 1].push(new Class.geom.Point(_x + self.width / 2, _y + self.height / 2));
				}
				
				if (!lines[tl - 1]) {
					lines[tl - 1] = [];
				}
				lines[tl - 1].push(new Class.geom.Point(r_max * Math.cos(_corner * Math.PI / 180) + self.width / 2, r_max * Math.sin(_corner * Math.PI / 180) + self.height / 2));
			}
			
			var extraRender = function() {
				this.stage.ctx.save();
				this.stage.ctx.scale(this.scale * this.scaleX, this.scale * this.scaleY);
				
				this.stage.ctx.beginPath();
				this.stage.ctx.moveTo(this.point1.x - this.x, this.point1.y - this.y);
				this.stage.ctx.lineTo(this.point2.x - this.x, this.point2.y - this.y);
				this.stage.ctx.lineTo(this.point3.x - this.x, this.point3.y - this.y);
				this.stage.ctx.lineTo(this.point1.x - this.x, this.point1.y - this.y);
				this.stage.ctx.clip();
				this.stage.ctx.drawImage(self.broken_image, -this.x, -this.y);
				
				this.stage.ctx.restore();
			},
			oninit = function() {
				var min_x = Math.max(0, Math.min(this.point1.x, this.point2.x, this.point3.x)),
				min_y = Math.max(0, Math.min(this.point1.y, this.point2.y, this.point3.y)),
				max_x = Math.min(self.width, Math.max(this.point1.x, this.point2.x, this.point3.x)),
				max_y = Math.min(self.height, Math.max(this.point1.y, this.point2.y, this.point3.y));
				this.x = (min_x + max_x) / 2;
				this.y = (min_y + max_y) / 2;
				this.basex = this.x;
				this.basey = this.y;
			},
			animeProp = {
				progress : function(ev) {
					var scale = 1 - ev.ease * ev.ease;
					
					var scaleX = this.piece.scaleX - this.piece.scaleXSpeed * ev.ease;
					if (scaleX <= -1) {
						if (this.piece.scaleXSpeed > 0) {
							this.piece.scaleXSpeed *= -1;
						}
					} else if (scaleX >= 1) {
						if (this.piece.scaleXSpeed < 0) {
							this.piece.scaleXSpeed *= -1;
						}
					}
					
					var scaleY = this.piece.scaleY - this.piece.scaleYSpeed * ev.ease;
					if (scaleY <= -1) {
						if (this.piece.scaleYSpeed > 0) {
							this.piece.scaleYSpeed *= -1;
						}
					} else if (this.scaleY >= 1) {
						if (this.piece.scaleYSpeed < 0) {
							this.piece.scaleYSpeed *= -1;
						}
					}
			
					var _x = self.width / 2 - (self.width / 2 - this.piece.basex) * scale, _y = self.height / 2 - (self.height / 2 - this.piece.basey) * scale - self.height / 2 * 0.5 * Math.abs(0.5 - Math.pow(ev.percent, 0.1));
			
					this.piece.setProp({
						scale : scale,
						x : _x,
						y : _y,
						scaleX : scaleX,
						scaleY : scaleY,
						alpha : scaleX * scaleY
					});
				},
				after : function() {
					this.piece.remove();
				},
				easing : 'circin'
			};
			
			for (var i = 0, l = lines.length; i < l; i++) {
				var line_this = lines[i], pi = 0, pl = line_this.length;
				if (i === 0) {
					// 从原点开始的，创建一个三角形碎片
					for (; pi < pl; pi++) {
						var piece = new Class.display.Sprite({
							extraRender : extraRender
						}),
						point_this = line_this[pi], // 当前点
						point_next = (pi === pl - 1) ? line_this[0] : line_this[pi + 1]; // 三角形的另一顶点
						
						piece.point1 = center; // 基础顶点为原点
						piece.point2 = point_this;
						piece.point3 = point_next;
						piece.scale = 1;
						piece.scaleX = 1;
						piece.scaleY = 1;
						piece.scaleXSpeed = Math.random() * this.turn_speed;
						piece.scaleYSpeed = Math.random() * this.turn_speed;
						oninit.apply(piece);
						this.render.appendChildAt(piece, 0);
						
						var duration = this.usetime + Math.random() * this.usetime / 10;
						animeProp.duration = duration;
						animeProp.delay = 0;
						var anime = SimpleAnime(animeProp);
						anime.piece = piece;
					}
				} else {
					for (; pi < pl; pi++) {
						// 不是从原点开始，则分隔为两个三角形碎片
						var piece1 = new Class.display.Sprite({
							extraRender : extraRender
						}),
						piece2 = new Class.display.Sprite({
							extraRender : extraRender
						}),
						line_prev = lines[i - 1], // 前一条纬度线
						point0 = line_this[pi], // 当前点
						point1, // 三角形另一顶点
						point0_prev = line_prev[pi], // 当前点在前一条纬度线的对应点
						point1_prev; // 三角形另一顶点在前一条纬度线的对应点
						
						if (pi === pl - 1) {
							point1 = line_this[0];
							point1_prev = line_prev[0];
						} else {
							point1 = line_this[pi + 1];
							point1_prev = line_prev[pi + 1];
						}
						
						this.render.appendChild(piece1);
						this.render.appendChild(piece2);
						
						piece1.point1 = point0;
						piece1.point2 = point1;
						piece2.point1 = point0_prev;
						piece2.point2 = point1_prev;
						
						if ((pi + i) % 2 === 0) {
							piece1.point3 = point0_prev;
							piece2.point3 = point1;
						} else {
							piece1.point3 = point1_prev;
							piece2.point3 = point0;
						}
						
						
						piece1.scale = 1;
						piece1.scaleX = 1;
						piece1.scaleY = 1;
						piece1.scaleXSpeed = Math.random() * this.turn_speed;
						piece1.scaleYSpeed = Math.random() * this.turn_speed;
						
						piece2.scale = 1;
						piece2.scaleX = 1;
						piece2.scaleY = 1;
						piece2.scaleXSpeed = Math.random() * this.turn_speed;
						piece2.scaleYSpeed = Math.random() * this.turn_speed;
						
						oninit.apply(piece1);
						oninit.apply(piece2);
						
						var duration1 = this.usetime + Math.random() * this.usetime / 10 * i;
						animeProp.duration = duration1;
						animeProp.delay = this.usetime / 5 * Math.pow(i, 0.5);
						var anime1 = SimpleAnime(animeProp);
						anime1.piece = piece1;
						
						var duration2 = this.usetime + Math.random() * this.usetime / 10 * i;
						animeProp.duration = duration2;
						animeProp.delay = this.usetime / 5 * Math.pow(i, 0.5);
						var anime2 = SimpleAnime(animeProp);
						anime2.piece = piece2;
					}
				}
			}
		}
	};
	
	window.BrokenGlass = BrokenGlass;
})();

/*
 * 跨屏彩蛋控制器
 */
(function() {
	var winWidth = document.documentElement.clientWidth, winHeight = document.documentElement.clientHeight,
	// 搜索结果DOM
	header = document.getElementById('header'), wrapper = document.getElementById('warper'),
	// canvas对象
	canvas = document.createElement('canvas'),
	// context画布
	context,
	// 用于切割的图片
	broken_image,
	broken_glass,
	last_frame,
	lastFrame,
	broken_sound,
	phone,
	// 手机翻转动画
	phone_frame,
	phoneFrames = [],
	// 片尾循环创建光束的动画
	piece_creater,
	// 屏幕呼吸动画
	screen_breath,
	isExit = false,
	start_time,
	// 初始化
	init = function(topImage) {
		html2canvas(document.body, {
			background : '#fff',
			proxy : true,
			useCORS : true,
			onrendered : function(c) {
				header && (header.style.display = 'none');
				wrapper && (wrapper.style.display = 'none');
					
				var easterEgg = document.createElement('div');
				easterEgg.id = 'easterEgg';
				document.body.appendChild(easterEgg);
				
				easterEgg.innerHTML = [
					'<style>',
					'#easterEgg{height:100%;left:0;position:fixed;top:0;width:100%;z-index:9999;}',
					'#easterEgg>span{background:url(https://p.ssl.qhimg.com/t011fab6f23e83afe9f.png) no-repeat;cursor:pointer;height:14px;position:absolute;right:38px;top:70px;width:17px;}',
					'#easterEgg #easter_egg_close{height:12px;right:40px;top:40px;width:13px;}',
					'#easterEgg #easter_egg_quiet{background-position:-20px 0;}',
					'#easterEgg #easter_egg_quiet.quiet{background-position:-40px 0;}',
					'</style>',
					'<span id="easter_egg_quiet"></span>',
					'<span id="easter_egg_close"></span>'
				].join('');
				
				broken_sound = document.createElement('audio');
				broken_sound.src = 'https://s.ssl.qhimg.com/static/30a28c6a64896347/break.mp3';
				
				var c_ctx = c.getContext('2d');
				c_ctx.drawImage(topImage, 0, 0, 80, 42, 20, 8, 80, 42);
				c_ctx.drawImage(topImage, 540, 42, 93, 36, 560, 50, 93, 36);
				
				easterEgg.appendChild(broken_sound);
				
				easterEgg.addEventListener('click', function(ev) {
					if (ev.target.id === 'easter_egg_close') {
						exit();
					} else if (ev.target.id === 'easter_egg_quiet') {
						if (ev.target.className === 'quiet') {
							ev.target.className = '';
							broken_sound.muted = false;
						} else {
							ev.target.className = 'quiet';
							broken_sound.muted = true;
						}
					}
				});
				
				winWidth = document.documentElement.clientWidth, winHeight = document.documentElement.clientHeight;
				canvas.width = winWidth;
				canvas.height = winHeight;
				easterEgg.appendChild(canvas);
		
				start_time = SimpleAnime.getTime();
				broken_image = c;
				throwPhone();
		
				window.addEventListener('resize', function() {
					winWidth = document.documentElement.clientWidth, winHeight = document.documentElement.clientHeight;
					broken_glass.width = winWidth;
					broken_glass.height = winHeight;
				});
			}
		});
	},
	// 图片预加载
	preload = function() {
		// 判断是否支持canvas
		try {
			context = canvas.getContext('2d');
		} catch(e) {
			return;
		}
		
		var imgs = ['https://p.ssl.qhimg.com/t01bd2904efdacbc51a.png', /*'https://p.ssl.qhimg.com/t01bd2904efdacbc51a.png', 'https://p.ssl.qhimg.com/t01cde1f884d0fd4a59.png', winWidth > 1200 ? 'https://p.ssl.qhimg.com/t01f7472a7bf014ee76.png' : 'https://p.ssl.qhimg.com/t01a659ebbc6fa5a2d6.png', */'https://p.ssl.qhimg.com/t017e82828800d04770.png',
			'https://p.ssl.qhimg.com/t01626bf08dc16c3b94.png', 'https://p.ssl.qhimg.com/t0192b858d2733c1438.png', 'https://p.ssl.qhimg.com/t012b7e2633f0815c13.png', 'https://p.ssl.qhimg.com/t01b0ea3119b1cc4e42.png', 'https://p.ssl.qhimg.com/t018752feea96251302.png', 'https://p.ssl.qhimg.com/t01dab69f8a34669dcb.png',
			'https://p.ssl.qhimg.com/t01710b6162aca41b4a.png', 'https://p.ssl.qhimg.com/t0183d95fed5b107baf.png', 'https://p.ssl.qhimg.com/t01f66c85ed30546ac9.png', 'https://p.ssl.qhimg.com/t01c22dad3a9cc6179f.png', 'https://p.ssl.qhimg.com/t012f31282d11b57be9.png', 'https://p.ssl.qhimg.com/t01ce3d94ce5b6d291b.png'],
		l = imgs.length, loaded = 0, topImage;
		for (var i = 0; i < l; i++) {
			var img = new Image;
			if (i === 0) {
				topImage = img;
			} else if (i === 1) {
				last_frame = img;
			} else {
				phoneFrames.push(img);
			}
			img.onload = function() {
				if (++loaded === l) {
					init(topImage);
				}
			};
			img.src = imgs[i];
			
		}
	},
	throwPhone = function() {
		broken_glass = new BrokenGlass({
			canvas : canvas,
			width : winWidth,
			height : winHeight,
			broken_image : broken_image,
			longitude : 21,
			latitude : 7,
			scale_step : 0.6,
			usetime : 2000
		});
		document.getElementById('easterEgg').style['background-color'] = '#000';
		
		phone = new Class.display.Sprite({
			x : winWidth / 2,
			y : winHeight / 2,
			alpha : 0,
			extraRender : function() {
				this.stage.ctx.save();
				this.stage.ctx.scale(this.scale, this.scale);
				this.stage.ctx.drawImage(phoneFrames[this.frame], -300, -360 + this.extraY);
				this.stage.ctx.restore();
			}
		});
		phone.addEventListener('resize', function() {
			SimpleAnime.raf(function() {
				this.x = winWidth / 2;
				this.y = winHeight / 2;
			}, this);
		});
		phone.frame = 0;
		phone.scale = 4;
		phone.extraY = winHeight / 2;
		
		broken_glass.render.appendChild(phone);
		
		var punched = false, create = false;
		phone_frame = SimpleAnime({
			loop : 0,
			progress : function(ev) {
				var frame = phone.frame + 1;
				if (frame === 12) {
					frame = 0;
				}
				phone.setProp({
					frame : frame
				});
				
				if (!punched && SimpleAnime.getTime() - start_time >= 500) {
					if (frame === 0) {
						if (!create) {
							createBroken();
						}
						punched = true;
						punch();
						this.destroy();
					} else if (frame === 10) {
						create = true;
						createBroken();
					}
				}
			}
		});
		
		SimpleAnime({
			delay : 200,
			duration : 400,
			progress : function(ev) {
				phone.setProp({
					scale : 4 - ev.ease * 3.3,
					extraY : winHeight / 2 * (1 - SimpleAnime.getEasing(ev.percent, 'circ')[0]),
					alpha : ev.ease
				});
			}
		});
		
		SimpleAnime({
			duration : 10000,
			after : function() {
				exit();
			}
		});
	},
	createBroken = function() {
		broken_glass.createBroken();
		phone.parent && phone.parent.setChildIndex(phone, phone.parent.numChildren);
		SimpleAnime({
			duration : 100,
			after : function() {
				// 玻璃破碎音效
				broken_sound.play();
			}
		});
	},
	punch = function() {
		if (isExit) return;
		
		lastFrame = new Class.display.Sprite({
			x : phone.x,
			y : phone.y,
			alpha : 0,
			extraRender : function() {
				this.stage.ctx.save();
				this.stage.ctx.scale(phone.scale, phone.scale);
				this.stage.ctx.rect(-186, phone.extraY - 298, 372, 588);
				this.stage.ctx.clip();
				this.stage.ctx.drawImage(last_frame, -186 * this.scale, phone.extraY - 294 * this.scale - 4, 372 * this.scale, 588 * this.scale);
				this.stage.ctx.restore();
			}
		});
		lastFrame.scale = 1;
		lastFrame.addEventListener('resize', function() {
			SimpleAnime.raf(function() {
				this.x = phone.x;
				this.y = phone.y;
			}, this);
		});
		broken_glass.render.appendChild(lastFrame);
		broken_glass.render.canvas.addEventListener('click', canvasClick);
		broken_glass.render.canvas.addEventListener('mousemove', canvasMouseMove);
		
		SimpleAnime({
			delay : 1000,
			duration : 2000,
			beforeloop : function() {
				if (isExit) return;
				
				createPiece();
		
				screen_breath = SimpleAnime({
					delay : 1000,
					duration : 3000,
					progress : function(ev) {
						lastFrame.setProp({
							scale : 1.1 - Math.abs(ev.ease - 0.5) * 0.2
						});
					},
					after : function(){
						this.restart();
					}
				});
			},
			progress : function(ev) {
				lastFrame.setProp({
					alpha : ev.ease,
					y : phone.y
				});
			}
		});
		
		SimpleAnime({
			delay : 1000,
			duration : 2500,
			beforeloop : function() {
				if (isExit) return;
				phone.parent && phone.parent.setChildIndex(phone, 21 * 7);
				phone.parent && phone.parent.setChildIndex(lastFrame, 21 * 7 + 1);
				SimpleAnime({
					duration : 1000,
					after : function() {
						phone.parent && phone.parent.setChildIndex(phone, 21 * 5);
						phone.parent && phone.parent.setChildIndex(lastFrame, 21 * 5 + 1);
					}
				});
			},
			progress : function(ev) {
				phone.setProp({
					scale : 0.7 - ev.ease * 0.2,
					extraY : - 50 * ev.ease
				});
			},
			easing : 'quadin'
		});
	},
	createPiece = function() {
		piece_creater = SimpleAnime({
			duration : 50,
			loop : 0,
			beforeloop : function() {
				var piece = new Class.display.Sprite({
					x : winWidth / 2,
					y : winHeight / 2,
					extraRender : function() {
						this.stage.ctx.save();
						this.stage.ctx.scale(this.scale, this.scale);
						this.stage.ctx.fillStyle = '#c6ff8f';
						this.stage.ctx.beginPath();
						this.stage.ctx.moveTo(this.point0.x, this.point0.y);
						this.stage.ctx.lineTo(this.point1.x, this.point1.y);
						this.stage.ctx.lineTo(this.point2.x, this.point2.y);
						this.stage.ctx.lineTo(this.point0.x, this.point0.y);
						this.stage.ctx.fill();
						this.stage.ctx.restore();
					}
				});
				var corner = Math.random() * 360, angel = Math.random() + 1, side1 = Math.random() * 20 + 10, side2 = Math.random() * 20 + 10;
				piece.scale = 1;
				piece.point0 = new Class.geom.Point(0, 0);
				piece.point1 = new Class.geom.Point(side1 * Math.cos((corner - angel) * Math.PI / 180), side1 * Math.sin((corner - angel) * Math.PI / 180));
				piece.point2 = new Class.geom.Point(side2 * Math.cos((corner + angel) * Math.PI / 180), side2 * Math.sin((corner + angel) * Math.PI / 180));
				
				broken_glass.render.appendChildAt(piece, 0);
				
				SimpleAnime({
					duration : Math.random() * 1200 + 300,
					progress : function(ev) {
						piece.setProp({
							x : winWidth / 2 * (1 + ev.ease * Math.cos(corner * Math.PI / 180)),
							y : winHeight / 2 + winWidth / 2 * ev.ease * Math.sin(corner * Math.PI / 180),
							scale : 1 + ev.ease * 9,
							alpha : 1 - ev.ease
						});
					},
					after : function() {
						piece.remove();
					}
				});
			}
		});
	},
	canvasClick = function(ev) {
		if (Math.abs(ev.clientX - lastFrame.x) < 100 && Math.abs(ev.clientY - lastFrame.y) < 150) {
			location.href = 'http://se.360.cn/kuaping/index.html';
		}
	},
	canvasMouseMove = function(ev) {
		if (Math.abs(ev.clientX - lastFrame.x) < 100 && Math.abs(ev.clientY - lastFrame.y) < 150) {
			this.style.cursor = 'pointer';
		} else {
			this.style.cursor = 'default';
		}
	},
	exit = function() {
		if (broken_glass) {
			broken_glass.render.canvas.removeEventListener('click', canvasClick);
			broken_glass.render.canvas.removeEventListener('mousemove', canvasMouseMove);
			broken_glass.render.destroy();
		}
		document.body.removeChild(document.getElementById('easterEgg'));
		
		// 销毁一些无限循环的动画
		phone_frame && phone_frame.destroy();
		piece_creater && piece_creater.destroy();
		screen_breath && screen_breath.destroy();
		
		header && (header.style.display = '');
		wrapper && (wrapper.style.display = '');
		
		isExit = true;
	};
	
	preload();
})();