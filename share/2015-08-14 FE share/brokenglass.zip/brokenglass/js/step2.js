/*
 * 破碎玻璃效果
 */
(function() {
	var BrokenGlass = function(option) {
		if (!option.broken_image) {
			throw('请输入要碎裂的图片');
		}
		
		var pieces = [],
		broken_image = option.broken_image,
		longi = option.longitude > 4 && parseInt(option.longitude) || 12,
		lati = option.latitude > 3 && parseInt(option.latitude) || 5,
		scale_step = option.scale_step <= 0.8 && option.scale_step >= 0.1 && parseFloat(option.scale_step) || 0.5,
		turn_speed = option.turn_speed < 0.1 && option.turn_speed > 0 && parseFloat(option.turn_speed) || 0.05,
		usetime = option.usetime > 1000 && parseInt(option.usetime) || 2000;
		
		Class.imageCache[broken_image.src] = broken_image;
		
		this.width = option.width || document.documentElement.clientWidth;
		this.height = option.height || document.documentElement.clientHeight;
		
		Object.defineProperties(this, {
			ctx : {
				get : function() {
					return option.canvas.getContext('2d');
				}
			},
			pieces : {
				get : function() {
					return pieces;
				}
			},
			longitude : {
				get : function() {
					return longi;
				}
			},
			latitude : {
				get : function() {
					return lati;
				}
			},
			scale_step : {
				get : function() {
					return scale_step;
				}
			},
			turn_speed : {
				get : function() {
					return turn_speed;
				}
			},
			usetime : {
				get : function() {
					return usetime;
				}
			},
			broken_image : {
				get : function() {
					return broken_image;
				}
			}
		});
		
		this.createBroken();
	};
	BrokenGlass.prototype = {
		constructor : BrokenGlass,
		/*
		 * 创建破碎玻璃块
		 */
		createBroken : function() {
			// 首先清除原始图
			// this.render.children[0].remove();
			
			var self = this,
			r_max = Math.max(this.width, this.height); // 简单粗暴……最大半径等于最小边长
			
			this.ctx.strokeStyle = '#000';
			this.ctx.lineWidth = 3;
			for (var gi = 0, gl = this.longitude; gi < gl; gi++) {
				var _corner = gi * 360 / gl + Math.random() * 180 / gl - 90 / gl; // 本条直线的角度
				this.ctx.beginPath();
				this.ctx.moveTo(self.width / 2, self.height / 2);
				for (var ti = 1, tl = this.latitude; ti < tl; ti++) {
					// 缩放比例
					var scale = Math.pow(this.scale_step, tl - ti);
					
					// 计算随机偏移半径
					var r = r_max * scale, r_real = r * (1.2 - Math.random() * 0.4);
					// 计算随机偏移角度
					var c_real = _corner + Math.random() * 90 / gl - 45 / gl;
					// 生成最终随机偏移节点
					var _x = r_real * Math.cos(c_real * Math.PI / 180), _y = r_real * Math.sin(c_real * Math.PI / 180);
					
					this.ctx.lineTo(_x + self.width / 2, _y + self.height / 2);
					this.ctx.fillRect(_x + self.width / 2 - 5, _y + self.height / 2 - 5, 10, 10);
				}
				this.ctx.lineTo(r_max * Math.cos(_corner * Math.PI / 180) + self.width / 2, r_max * Math.sin(_corner * Math.PI / 180) + self.height / 2);
				this.ctx.stroke();
			}
		}
	};
	
	window.BrokenGlass = BrokenGlass;
})();

/*
 * 跨屏彩蛋控制器
 */
(function() {
	var winWidth = document.documentElement.clientWidth, winHeight = document.documentElement.clientHeight,
	// 搜索结果DOM
	header = document.getElementById('header'), wrapper = document.getElementById('warper'),
	// canvas对象
	canvas = document.createElement('canvas'),
	// context画布
	context,
	// 用于切割的图片
	broken_image,
	broken_glass,
	last_frame,
	lastFrame,
	broken_sound,
	phone,
	// 手机翻转动画
	phone_frame,
	phoneFrames = [],
	// 片尾循环创建光束的动画
	piece_creater,
	// 屏幕呼吸动画
	screen_breath,
	isExit = false,
	start_time,
	// 初始化
	init = function(topImage) {
		html2canvas(document.body, {
			background : '#fff',
			proxy : true,
			useCORS : true,
			onrendered : function(c) {
				header && (header.style.display = 'none');
				wrapper && (wrapper.style.display = 'none');
					
				var easterEgg = document.createElement('div');
				easterEgg.id = 'easterEgg';
				document.body.appendChild(easterEgg);
				
				easterEgg.innerHTML = [
					'<style>',
					'#easterEgg{height:100%;left:0;position:fixed;top:0;width:100%;z-index:9999;}',
					'#easterEgg>span{background:url(https://p.ssl.qhimg.com/t011fab6f23e83afe9f.png) no-repeat;cursor:pointer;height:14px;position:absolute;right:38px;top:70px;width:17px;}',
					'#easterEgg #easter_egg_close{height:12px;right:40px;top:40px;width:13px;}',
					'#easterEgg #easter_egg_quiet{background-position:-20px 0;}',
					'#easterEgg #easter_egg_quiet.quiet{background-position:-40px 0;}',
					'</style>',
					'<span id="easter_egg_quiet"></span>',
					'<span id="easter_egg_close"></span>'
				].join('');
				
				broken_sound = document.createElement('audio');
				broken_sound.src = 'https://s.ssl.qhimg.com/static/30a28c6a64896347/break.mp3';
				
				var c_ctx = c.getContext('2d');
				c_ctx.drawImage(topImage, 0, 0, 80, 42, 20, 8, 80, 42);
				c_ctx.drawImage(topImage, 540, 42, 93, 36, 560, 50, 93, 36);
				
				easterEgg.appendChild(broken_sound);
				
				easterEgg.addEventListener('click', function(ev) {
					if (ev.target.id === 'easter_egg_close') {
						exit();
					} else if (ev.target.id === 'easter_egg_quiet') {
						if (ev.target.className === 'quiet') {
							ev.target.className = '';
							broken_sound.muted = false;
						} else {
							ev.target.className = 'quiet';
							broken_sound.muted = true;
						}
					}
				});
				
				winWidth = document.documentElement.clientWidth, winHeight = document.documentElement.clientHeight;
				canvas.width = winWidth;
				canvas.height = winHeight;
				easterEgg.appendChild(canvas);
		
				start_time = SimpleAnime.getTime();
				broken_image = c;
				throwPhone();
		
				window.addEventListener('resize', function() {
					winWidth = document.documentElement.clientWidth, winHeight = document.documentElement.clientHeight;
					broken_glass.width = winWidth;
					broken_glass.height = winHeight;
				});
			}
		});
	},
	// 图片预加载
	preload = function() {
		// 判断是否支持canvas
		try {
			context = canvas.getContext('2d');
		} catch(e) {
			return;
		}
		
		var imgs = ['https://p.ssl.qhimg.com/t01bd2904efdacbc51a.png', /*'https://p.ssl.qhimg.com/t01bd2904efdacbc51a.png', 'https://p.ssl.qhimg.com/t01cde1f884d0fd4a59.png', winWidth > 1200 ? 'https://p.ssl.qhimg.com/t01f7472a7bf014ee76.png' : 'https://p.ssl.qhimg.com/t01a659ebbc6fa5a2d6.png', */'https://p.ssl.qhimg.com/t017e82828800d04770.png',
			'https://p.ssl.qhimg.com/t01626bf08dc16c3b94.png', 'https://p.ssl.qhimg.com/t0192b858d2733c1438.png', 'https://p.ssl.qhimg.com/t012b7e2633f0815c13.png', 'https://p.ssl.qhimg.com/t01b0ea3119b1cc4e42.png', 'https://p.ssl.qhimg.com/t018752feea96251302.png', 'https://p.ssl.qhimg.com/t01dab69f8a34669dcb.png',
			'https://p.ssl.qhimg.com/t01710b6162aca41b4a.png', 'https://p.ssl.qhimg.com/t0183d95fed5b107baf.png', 'https://p.ssl.qhimg.com/t01f66c85ed30546ac9.png', 'https://p.ssl.qhimg.com/t01c22dad3a9cc6179f.png', 'https://p.ssl.qhimg.com/t012f31282d11b57be9.png', 'https://p.ssl.qhimg.com/t01ce3d94ce5b6d291b.png'],
		l = imgs.length, loaded = 0, topImage;
		for (var i = 0; i < l; i++) {
			var img = new Image;
			if (i === 0) {
				topImage = img;
			} else if (i === 1) {
				last_frame = img;
			} else {
				phoneFrames.push(img);
			}
			img.onload = function() {
				if (++loaded === l) {
					init(topImage);
				}
			};
			img.src = imgs[i];
			
		}
	},
	throwPhone = function() {
		broken_glass = new BrokenGlass({
			canvas : canvas,
			width : winWidth,
			height : winHeight,
			broken_image : broken_image,
			longitude : 21,
			latitude : 7,
			scale_step : 0.6,
			usetime : 2000
		});
	};
	
	preload();
})();