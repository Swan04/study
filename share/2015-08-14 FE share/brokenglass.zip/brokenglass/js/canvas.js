
/* Simple JavaScript Inheritance
* By John Resig http://ejohn.org/
* MIT Licensed.
*/
// Inspired by base2 and Prototype
(function() {
	var initializing = false, fnTest = /xyz/.test(function() {xyz;}) ? /\b_super\b/ : /.*/;

	// The base Class implementation (does nothing)
	this.Class = function() {};

	// Create a new Class that inherits from this class
	Class.extend = function(prop) {
		var _super = this.prototype;

		// Instantiate a base class (but only create the instance,
		// don't run the init constructor)
		initializing = true;
		var prototype = new this();
		initializing = false;

		// Copy the properties over onto the new prototype
		for (var name in prop) {
			// Check if we're overwriting an existing function
			prototype[name] = typeof prop[name] == "function" && typeof _super[name] == "function" && fnTest.test(prop[name]) ? (function(name, fn) {
				return function() {
					var tmp = this._super;

					// Add a new ._super() method that is the same method
					// but on the super-class
					this._super = _super[name];

					// The method only need to be bound temporarily, so we
					// remove it when we're done executing
					var ret = fn.apply(this, arguments);
					this._super = tmp;

					return ret;
				};
			})(name, prop[name]) : prop[name];
		}

		// The dummy class constructor
		function Class() {
			// All construction is actually done in the init method
			if (!initializing && this.init)
				this.init.apply(this, arguments);
		}

		// Populate our constructed prototype object
		Class.prototype = prototype;

		// Enforce the constructor to be what we expect
		Class.prototype.constructor = Class;

		// And make this class extendable
		Class.extend = arguments.callee;
		
		return Class;
	};
	
	Class.utils = {};
	Class.geom = {};
	Class.display = {};
	Class.imageCache = {};
})();

/*
 * 事件
 */
(function() {
	var _Event = Class.extend({
		init : function(eventname) {
			if (!eventname || typeof eventname !== 'string') {
				throw('请传入事件名称！');
			}
			var bubble = false;
			Object.defineProperties(this, {
				type : {
					value : eventname.toLowerCase()
				},
				bubble : {
					get : function() {
						return bubble;
					},
					set : function(val) {
						bubble = !!val;
					}
				}
			});
		},
		stopPaganation : function() {
			this.bubble = false;
		}
	});
	Class.utils.Event = _Event;
})();

/*
 * 二维空间点，用于hitTest
 */
(function() {
	var Point = Class.extend({
		init : function(x, y) {
			Object.defineProperties(this, {
				x : {
					value : x || 0
				},
				y : {
					value : y || 0
				}
			});
		}
	});
	Class.geom.Point = Point;
})();

/*
 * 矩形，用于测定范围
 */
(function() {
	var Rectangle = Class.extend({
		init : function(x, y, width, height) {
			Object.defineProperties(this, {
				x : {
					value : x || 0
				},
				y : {
					value : y || 0
				},
				width : {
					value : width || 0
				},
				height : {
					value : height || 0
				}
			});
		}
	});
	Class.geom.Rectangle = Rectangle;
})();

/*
 * 精灵类，实现子对象管理相关功能
 */
(function() {
	var Sprite = Class.extend({
		init : function(option) {
			// 坐标
			var x = 0, y = 0;
			// 舞台
			var stage = null;
			// 父元素
			var parent = null;
			// 对象名称
			var name = '';
			// 透明度
			var alpha = parseFloat(option.alpha);
			if (typeof alpha !== 'number' || !isFinite(alpha)) {
				alpha = 1;
			}
			// 旋转
			//var rotate = 0;
			// 缩放
			//var scaleX = 1, scaleY = 1;
			// 鼠标响应
			var isActive = false;
			// 是否渲染
			var visible = true;
			// 额外渲染
			var extraRender = null;
			
			Object.defineProperties(this, {
				depth : {
					get : function() {
						for (var d = 0, l = this.parent.numChildren; d < l; d++) {
							if (this.parent.children[d] === this) {
								return d;
							}
						}
						return null;
					}
				},
				x : {
					get : function() {
						return x;
					},
					set : function(val) {
						val = parseInt(val);
						if (!isNaN(val)) {
							x = val;
						}
					}
				},
				y : {
					get : function() {
						return y;
					},
					set : function(val) {
						val = parseInt(val);
						if (!isNaN(val)) {
							y = val;
						}
					}
				},
				parent : {
					get : function() {
						return parent;
					},
					set : function(val) {
						if ((val instanceof Sprite) || val === null) {
							parent = val;
						}
					}
				},
				stage : {
					get : function() {
						return stage;
					},
					set : function(val) {
						if ((val instanceof Class.display.Stage) || val === null) {
							stage = val;
						}
					}
				},
				alpha : {
					get : function() {
						return alpha;
					},
					set : function(val) {
						val = parseFloat(val);
						if (!isNaN(val)) {
							alpha = Math.min(1, Math.max(0, val));
						}
					}
				},
				isActive : {
					get : function() {
						return isActive;
					},
					set : function(val) {
						isActive = !!val;
					}
				},
				visible : {
					get : function() {
						return visible;
					},
					set : function(val) {
						visible = !!val;
					}
				},
				// 事件缓存
				EvCache : {
					value : []
				},
				children : {
					value : []
				},
				numChildren : {
					get : function() {
						return this.children.length;
					}
				},
				// 额外渲染
				extraRender : {
					get : function() {
						return extraRender;
					},
					set : function(val) {
						if (val === null || typeof val === 'function') {
							extraRender = val;
						}
					}
				}
			});
			
			this.x = option.x;
			this.y = option.y;
			this.visible = option.visible !== false;
			this.extraRender = option.extraRender;
			this.addEventListener('ADDED_TO_STAGE', this.addedToStage);
		},
		/*
		 * 设置属性方法
		 */
		setProp : function(prop) {
			for (var i in prop) {
				this[i] = prop[i];
			}
			if (this.stage) {
				this.stage.repaint = true;
			}
		},
		/*
		 * 绑定事件方法
		 * @param {String} eventname 事件名称
		 * @param {Function|Array|String} callback 回调方法
		 * @param {Boolean} priority 默认false，先绑定的方法先执行，传入true则可以使后绑定的方法优先执行
		 */
		addEventListener : function(eventname, callback, priority) {
			if ( typeof eventname === 'string' && callback) {
				eventname = eventname.toLowerCase();
				
				if (!this.EvCache[eventname]) {
					this.EvCache[eventname] = [];
				}
				
				var operate = priority ? 'unshift' : 'push';
				if ( typeof callback === 'string') {
					try {
						callback = (new Function('return ' + callback))();
					} catch(e) {}
				}
				if ( typeof callback === 'function') {
					this.EvCache[eventname][operate](callback);
				} else if (Array.isArray(callback)) {
					for (var ei = 0, el = callback.length; ei < el; ei++) {
						if ( typeof callback[ei] === 'function') {
							this.EvCache[eventname][operate](callback[ei]);
						}
					}
				}
			}
		},
		/*
		 * 解除事件绑定
		 * @param {String} eventname 事件名称，不传此参数则清空全部事件监听
		 * @param {Function} callback 解除绑定的方法，不传此参数则解除该事件的全部绑定
		 */
		removeEventListener : function(eventname, callback) {
			if ( typeof eventname === 'string') {
				eventname = eventname.toLowerCase();
				// 第一个参数必须是事件类型字符串
				if (this.EvCache[eventname] && this.EvCache[eventname].length) {
					if (callback && (typeof callback === 'string' || typeof callback === 'function')) {
						for (var ei = this.EvCache[eventname].length; ei--; ) {
							var fn = this.EvCache[eventname][ei];
							// 判断方法是否相等，同时也判断方法的字符串是否相等
							if (fn === callback || fn.toString().replace(/\s/g, '') === callback.toString().replace(/\s/g, '')) {
								this.EvCache[eventname].splice(ei, 1);
								// 不中断循环，避免有重复绑定同一个方法的情况
								// break;
							}
						}
					} else {
						this.EvCache[eventname] = null;
						delete this.EvCache[eventname];
					}
				}
			} else {
				// 第一个参数无效，直接清空所有事件监听
				for (var e in this.EvCache) {
					this.removeEventListener(e);
				}
			}
		},
		/*
		 * 触发指定事件
		 * @param {String} eventname 事件名称
		 */
		dispatchEvent : function(ev) {
			if ( typeof ev === 'string') {
				ev = new Class.utils.Event(ev);
				ev.target = this;
			}
			if (!(ev instanceof Class.utils.Event)) {
				return;
			}
			var args = Array.prototype.slice.call(arguments, 1);
			args.unshift(ev);
			if (this.EvCache[ev.type] && this.EvCache[ev.type].length) {
				for (var ei = 0, el = this.EvCache[ev.type].length; ei < el; ei++) {
					if (this.EvCache[ev.type][ei].apply(this, args) === false) {
						return false;
					}
				}
			}
			
			// 判断事件是否冒泡
			if (ev.bubble && this.parent) {
				this.parent.dispatchEvent.apply(this.parent, args);
			}
		},
		/*
		 * 移除所有的事件监听
		 */
		destroyEvent : function() {
			for (var ei in this.EvCache) {
				this.EvCache[ei] = null;
				delete this.EvCache[ei];
			}
			this.EvCache.splice(0);
		},
		/*
		 * 渲染方法，逐级传入父元素的偏移量和透明度
		 * @param x, y {Number} 偏移量
		 * @param alpha {Number} 实际透明度
		 */
		prepareRender : function(x, y, alpha) {
			if (!this.stage || !this.visible) return false;
			
			x += this.x;
			y += this.y;
			alpha *= this.alpha;
			
			if (alpha <= 0 || x > this.stage.width || y > this.stage.height || x + this.width < 0 || y + this.contentHeight < 0) {
				return false;
			}
			
			this.stage.ctx.save();
			this.stage.ctx.globalAlpha = alpha;
			this.stage.ctx.translate(x, y);
			this.render();
			
			this.extraRender && this.extraRender();
			this.stage.ctx.restore();
			
			/*
			 * 渲染每个子类
			 */
			for (var i = 0, l = this.numChildren; i < l; i++) {
				this.children[i].prepareRender(x + this.x, y + this.y, alpha * this.alpha);
			}
		},
		/*
		 * 用于复写的实际渲染方法
		 */
		render : function() {},
		remove : function() {
			this.destroyEvent();
			this.stage = null;
			if (this.parent) {
				this.parent.removeChildAt(this.depth);
				this.parent = null;
			}
			this.removeChildren();
		},
		removeChildren : function() {
			for (var d = this.numChildren; d--; ) {
				this.children[d].remove();
			}
		},
		/*
		 * 判断是否处于某个对象之内
		 */
		includeBy : function(el) {
			if (this.stage && el instanceof Class.display.Sprite) {
				var parent = this.parent;
				while (parent !== this.stage) {
					if (parent === el) {
						return true;
					}
					parent = parent.parent;
				}
			}
			return false;
		},
		hitTest : function(point, x, y) {
			if (!this.stage || !this.visible) return false;
			
			var _x = x || 0, _y = y || 0;
			_x += this.x;
			_y += this.y;
			
			for (var i = this.numChildren; i--; ) {
				var hit_test = this.children[i].hitTest(point, _x, _y);
				if (hit_test) {
					return hit_test;
				}
			}
			return false;
		},
		appendChild : function(el) {
			this.appendChildAt(el, this.numChildren);
			return this;
		},
		appendChildAt : function(el, i) {
			i = parseInt(i);
			if (el instanceof Sprite && !(el instanceof Class.display.Stage) && !isNaN(i)) {
				if (el.parent) {
					el.parent.removeChild(el);
				}
				var l = this.numChildren;
				i = Math.max(0, Math.min(i, l));
				el.parent = this;
				this.children.splice(i, 0, el);
				if (this.stage && el.stage !== this.stage) {
					el.stage = this.stage;
					el.dispatchEvent('ADDED_TO_STAGE');
				}
				if (this.stage) {
					this.stage.repaint = true;
				}
			}
			return this;
		},
		/*
		 * 批量插入子元素
		 */
		appendChildren : function() {
			for (var i = 0, l = arguments.length; i < l; i++) {
				this.appendChildAt(arguments[i], this.numChildren);
			}
		},
		getChildAt : function(i) {
			return this.children[i];
		},
		getChildByName : function(name) {
			if (!name)
				return null;
			for (var d = this.numChildren; d--; ) {
				var _child = this.children[d];
				if (_child.name === name) {
					return _child;
				}
			}
			return null;
		},
		getChildrenByType : function(TypeClass) {
			var result = [];
			for (var i = 0; i < this.numChildren; i++) {
				if (this.children[i] instanceof TypeClass) {
					result.push(this.children[i]);
				}
			}
			return result;
		},
		removeChild : function(el) {
			return this.removeChildAt(el.depth);
		},
		removeChildAt : function(i) {
			this.children.splice(i, 1);
			if (this.stage) {
				this.stage.repaint = true;
			}
			return this;
		},
		getChildIndex : function(el) {
			if (!el || el.parent !== this)
				return null;
			return el.depth;
		},
		setChildIndex : function(el, i) {
			var _d = el.depth, l = this.numChildren;
			if (_d === i) {
				return this;
			}
			this.children.splice(_d, 1);
			this.children.splice(i, 0, el);
			return this;
		},
		/*
		 * 判断是否包含某个子对象
		 */
		include : function(el) {
			for (var i = 0; i < this.numChildren; i++) {
				if (this.children[i] === el) {
					return true;
				}
				if (this.children[i] instanceof Sprite) {
					if (this.children[i].include(el)) {
						return true;
					}
				}
			}
			return false;
		},
		/*
		 * 放入场景时，处理所有子对象
		 */
		addedToStage : function(ev) {
			if (this.numChildren) {
				for (var i = 0, l = this.numChildren; i < l; i++) {
					this.children[i].stage = this.stage;
					this.children[i].dispatchEvent('ADDED_TO_STAGE');
				}
			}
		}
	});
	Class.display.Sprite = Sprite;
})();

/*
 * 舞台，Canvas渲染的根元素
 */
(function() {
	var Stage = Class.display.Sprite.extend({
		init : function(option) {
			this._super(option);
			this.stage = this;
			
			var ctx, ratioX, ratioY, width, height, repaint = true;
			
			Object.defineProperties(this, {
				ctx : {
					get : function() {
						return ctx;
					},
					set : function(val) {
						if ((val instanceof CanvasRenderingContext2D) || val === null) {
							ctx = val;
						}
					}
				},
				ratioX : {
					get : function() {
						return ratioX;
					},
					set : function(val) {
						val = parseFloat(val);
						if (!isNaN(val)) {
							ratioX = val;
						}
					}
				},
				ratioY : {
					get : function() {
						return ratioY;
					},
					set : function(val) {
						val = parseFloat(val);
						if (!isNaN(val)) {
							ratioY = val;
						}
					}
				},
				width : {
					get : function() {
						return width;
					},
					set : function(val) {
						val = parseInt(val);
						if (!isNaN(val)) {
							width = val;
						}
					}
				},
				height : {
					get : function() {
						return height;
					},
					set : function(val) {
						val = parseInt(val);
						if (!isNaN(val)) {
							height = val;
						}
					}
				},
				repaint : {
					get : function() {
						return repaint;
					},
					set : function(val) {
						repaint = !!val;
					}
				}
			});
			
			this.ctx = option.ctx;
			this.ratioX = option.ratioX;
			this.ratioY = option.ratioY;
			this.width = option.width;
			this.height = option.height;
		},
		/*
		 * 舞台的渲染规则单独处理
		 * 1、舞台自身不进行渲染
		 * 2、舞台在渲染子类前进行一次缩放
		 */
		prepareRender : function(x, y, alpha) {
			this.ctx.save();
			this.ctx.scale(this.ratioX, this.ratioY);
			/*
			 * 渲染每个子类
			 */
			for (var i = 0, l = this.numChildren; i < l; i++) {
				this.children[i].prepareRender(x + this.x, y + this.y, alpha * this.alpha);
			}
			this.ctx.restore();
		},
		/*
		 * 如果没有任何子对象触发碰撞，舞台自身将响应碰撞
		 */
		hitTest : function(point, x, y) {
			var child_hit_test = this._super(point, x, y);
			if (child_hit_test) {
				return child_hit_test;
			} else {
				return {
					target : this
				};
			}
		},
		// stage被remove表示整个舞台被销毁
		remove : function() {
			this._super();
		}
	});
	Class.display.Stage = Stage;
})();

/*
 * DOM图形
 */
(function(Sprite) {
	var _Image = Class.display.Sprite.extend({
		init : function(option) {
			this._super(option);
			var src = option.src;
			var clipX = 0, clipY = 0, clipWidth = 0, clipHeight = 0, width = 'auto', height = 'auto';
			Object.defineProperties(this, {
				src : {
					get : function() {
						return src;
					},
					set : function(val) {
						if (typeof val === 'string') {
							src = val;
						}
					}
				},
				width : {
					get : function() {
						return width;
					},
					set : function(val) {
						if (val === 'auto') {
							width = val;
						} else {
							val = parseInt(val);
							if (!isNaN(val)) {
								width = val;
							}
						}
					}
				},
				height : {
					get : function() {
						return height;
					},
					set : function(val) {
						if (val === 'auto') {
							height = val;
						} else {
							val = parseInt(val);
							if (!isNaN(val)) {
								height = val;
							}
						}
					}
				},
				clipX : {
					get : function() {
						return clipX;
					},
					set : function(val) {
						val = parseInt(val);
						if (!isNaN(val)) {
							clipX = val;
						}
					}
				},
				clipY : {
					get : function() {
						return clipY;
					},
					set : function(val) {
						val = parseInt(val);
						if (!isNaN(val)) {
							clipY = val;
						}
					}
				},
				clipWidth : {
					get : function() {
						return clipWidth;
					},
					set : function(val) {
						val = parseInt(val);
						if (!isNaN(val)) {
							clipWidth = val;
						}
					}
				},
				clipHeight : {
					get : function() {
						return clipHeight;
					},
					set : function(val) {
						val = parseInt(val);
						if (!isNaN(val)) {
							clipHeight = val;
						}
					}
				}
			});
			this.clipX = option.clipX;
			this.clipY = option.clipY;
			this.clipWidth = option.clipWidth;
			this.clipHeight = option.clipHeight;
			this.width = option.width;
			this.height = option.height;
		},
		loadImage : function(src) {
			this.src = src;
			if (!Class.imageCache[src]) {
				Class.imageCache[src] = new Image();
				var self = this;
				Class.imageCache[src].onload = function() {
					if (!this.width || !this.height || !this.src) return;
					if (self.height === 'auto' || self.width === 'auto') {
						if (self.height !== 'auto') {
							self.width = Math.round(self.height * this.width / this.height);
						} else if (self.width !== 'auto') {
							self.height = Math.round(self.width * this.height / this.width);
						} else {
							self.width = this.width;
							self.height = this.height;
						}
					}
					self.dispatchEvent('LOAD');
				};
				Class.imageCache[src].onerror = function() {
					self.dispatchEvent('ERROR');
				};
				Class.imageCache[src].src = src;
			}
		},
		addedToStage : function(ev) {
			this._super(ev);
			
			if (this.src) {
				this.loadImage(this.src);
			}
		},
		render : function() {
			this._super();
			if (!this.src || !Class.imageCache[this.src]) return;
			
			if (this.clipWidth && this.clipHeight) {
				this.stage.ctx.drawImage(Class.imageCache[this.src], this.clipX, this.clipY, this.clipWidth, this.clipHeight, this.x, this.y, this.width, this.height);
			} else {
				this.stage.ctx.drawImage(Class.imageCache[this.src], this.x, this.y, this.width, this.height);
			}
		}
	});
	Class.display.Image = _Image;
})();

(function() {
	var global_scale;
	
	var CanvasRender = Class.display.Stage.extend({
		init : function(option) {
			var canvas = option.canvas, noResize = option.noResize || false;
			if (!canvas || !canvas.tagName || canvas.tagName !== 'CANVAS') {
				throw('请传入canvas对象！');
			}
			global_scale = parseInt(option.global_scale) || 2;
			this._super(option);
			this.ctx = canvas.getContext('2d');
			
			Object.defineProperty(this, 'canvas', {
				value : canvas
			});
			
			var self = this;
			var documentElement = document.documentElement;
			var width = option.width || documentElement.clientWidth;
			var height = option.height || documentElement.clientHeight;
			
			this.ratioX =  this.ratioY = global_scale;
			this.width = width;
			this.height = height;
			
			canvas.style.width = width + 'px';
			canvas.style.height = height + 'px';
			canvas.setAttribute('width', width * global_scale);
			canvas.setAttribute('height', height * global_scale);
			
			var now = +new Date, fps = 0, len = 0;
			this.paintFn = option.debug ? function() {
				var repaint = self.repaint;
				self.paint();
				var _now = +new Date;
				if (repaint) {
					var _fps = Math.floor(1000 / (_now - now));
					fps += _fps, len++;
					var _average = Math.round(fps / len);
					self.ctx.fillStyle = '#000';
					self.ctx.font = '24px 微软雅黑';
					self.ctx.fillText('FPS : ' + Math.floor(1000 / (_now - now)) + ' / ' + _average, 10, 30);
				}
				now = _now;
			} : function() {
				self.paint();
			};
			SimpleAnime.listen(this.paintFn);
			
			if (!noResize && !option.width && !option.height) {
				this.resizeFunc = function() {
					var size = {};
					size.width = documentElement.clientWidth;
					size.height = documentElement.clientHeight;
					self.resize(size);
				};
				window.addEventListener('resize', this.resizeFunc);
			}
		},
		resize : function(option) {
			var documentElement = document.documentElement;
			var width = option.width || documentElement.clientWidth;
			var height = option.height || documentElement.clientHeight;
			documentElement.scrollTop = document.body.scrollTop = 0;
			
			this.width = width;
			this.height = height;
			
			this.canvas.style.width = width + 'px';
			this.canvas.style.height = height + 'px';
			this.canvas.setAttribute('width', width * global_scale);
			this.canvas.setAttribute('height', height * global_scale);
			
			for (var i = 0, l = this.numChildren; i < l; i++) {
				this.children[i].dispatchEvent('RESIZE');
			}
			this.repaint = true;
		},
		paint : function() {
			if (this.repaint) {
				this.ctx.clearRect(0, 0, this.canvas.getAttribute('width'), this.canvas.getAttribute('height'));
				this.prepareRender(0, 0, 1);
				this.repaint = false;
			}
		},
		destroy : function() {
			window.removeEventListener('resize', this.resizeFunc);
			SimpleAnime.unlisten(this.paintFn);
			
			this.remove();
			this.stage = this.canvas = this.ctx = null;
		}
	});
	
	window.CanvasRender = CanvasRender;
})();
